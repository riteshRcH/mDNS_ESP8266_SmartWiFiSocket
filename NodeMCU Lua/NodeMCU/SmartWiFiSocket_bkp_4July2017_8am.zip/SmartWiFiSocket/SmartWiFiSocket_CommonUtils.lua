local constant_filenames = require "SmartWiFiSocketConstFilenms"

TRI_COLOR_SETUP_LED_RED_OPIN = 0
TRI_COLOR_SETUP_LED_GREEN_OPIN = 1
TRI_COLOR_SETUP_LED_BLUE_OPIN = 2
TRI_COLOR_RELAY_INDICATOR_LED_RED_OPIN = 3
-- Pin 4 is used by Active Low onboard Blue LED for UART TX
TRI_COLOR_RELAY_INDICATOR_LED_GREEN_OPIN = 5
TRI_COLOR_RELAY_INDICATOR_LED_BLUE_OPIN = 6
FACTORY_RESET_REDO_INITIAL_SETUP_INT_IPIN = 7
RELAY_OPIN = 8

local toggleTriColorRed = false
local tmrBlinkTriColorRed = tmr.create()
tmrBlinkTriColorRed:register(500, tmr.ALARM_AUTO, function(timer)
        toggleTriColorRed = not toggleTriColorRed
        gpio.write(TRI_COLOR_SETUP_LED_RED_OPIN, toggleTriColorRed and gpio.HIGH or gpio.LOW)
    end)

local toggleTriColorBlue = false
local tmrBlinkTriColorBlue = tmr.create()
tmrBlinkTriColorBlue:register(500, tmr.ALARM_AUTO, function(timer)
        toggleTriColorBlue = not toggleTriColorBlue
        gpio.write(TRI_COLOR_SETUP_LED_BLUE_OPIN, toggleTriColorBlue and gpio.HIGH or gpio.LOW)
    end)

function init_wifi_mode(wifi_mode)
    -- wifi mode config taken from https://iotbytes.wordpress.com/wifi-configuration-on-nodemcu/
    
    wifi.setphymode(wifi.PHYMODE_N) -- IEEE 802.11n physical mode
    while wifi.setmode(wifi_mode) ~= wifi_mode do
    end
end

function init_wifi_portable_mode()
    -- wifi mode config taken from https://nodemcu.readthedocs.io/en/master/en/modules/wifi/#wifisetphymode
    
    wifi.setphymode(wifi.PHYMODE_B) -- IEEE 802.11b, more range, low Transfer rate, more current draw (from Node MCU docs)
    while wifi.setmode(wifi.SOFTAP) ~= wifi.SOFTAP do
    end
end

function create_action_result_indicator_file (filename)  -- max filename length 31 chars for ESP's file system
    local fd = file.open(filename, "w+")
    fd:close()
    fd = nil
    
    collectgarbage()
end

function remove_action_result_indicator_files_on_boot ()
    file.remove(constant_filenames.SNTP_SYNC_DONE_ONCE_ON_BOOT)
end

function unregister_all_wifi_eventmon_callbacks ()
    wifi.eventmon.unregister(wifi.eventmon.STA_GOT_IP)
    wifi.eventmon.unregister(wifi.eventmon.STA_DISCONNECTED)
    wifi.eventmon.unregister(wifi.eventmon.STA_CONNECTED)
    wifi.eventmon.unregister(wifi.eventmon.STA_AUTHMODE_CHANGE)
    wifi.eventmon.unregister(wifi.eventmon.STA_DHCP_TIMEOUT)
    wifi.eventmon.unregister(wifi.eventmon.AP_STACONNECTED)
    wifi.eventmon.unregister(wifi.eventmon.AP_STADISCONNECTED)
    wifi.eventmon.unregister(wifi.eventmon.AP_PROBEREQRECVED)
    wifi.eventmon.unregister(wifi.eventmon.WIFI_MODE_CHANGED)
end

function factory_reset_redo_initial_setup()
    local ONE_SHOT_FUTURE_TIMERS = "OSFT"
    local FUTURE_SCHEDULES = "FS"
    local RECURRING_SCHEDULES = "RS"
    local RECURRING_TIMERS = "RT"
    
    file.remove(constant_filenames.INITIAL_SETUP_DONE)
    file.remove(constant_filenames.MDNS_HOSTNAME)
    file.remove(constant_filenames.IS_INTERNET_MODE_CONFIGURED)
    file.remove(constant_filenames.SNTP_SYNC_DONE_ONCE_ON_BOOT)
    
    file.remove(ONE_SHOT_FUTURE_TIMERS)
    file.remove(FUTURE_SCHEDULES)
    file.remove(RECURRING_SCHEDULES)
    file.remove(RECURRING_TIMERS)

    node.restart()
end

function init_factory_reset_redo_initial_setup_interrupt()
    gpio.mode(FACTORY_RESET_REDO_INITIAL_SETUP_INT_IPIN, gpio.INT)
    
    gpio.trig(FACTORY_RESET_REDO_INITIAL_SETUP_INT_IPIN, "up", function(level, when)
            tmr.create():alarm(3200, tmr.ALARM_SINGLE, function(t)
            if gpio.read(FACTORY_RESET_REDO_INITIAL_SETUP_INT_IPIN) == 1 then
                factory_reset_redo_initial_setup()
            end
        end)
    end)
end

function indicate_relay_off_with_no_timer()
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_RED_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_GREEN_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_BLUE_OPIN, gpio.LOW)
end

function indicate_initial_setup_not_done()
    gpio.write(TRI_COLOR_SETUP_LED_RED_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_GREEN_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_BLUE_OPIN, gpio.LOW)
end

function init_tri_color_led_pins()
    gpio.mode(TRI_COLOR_RELAY_INDICATOR_LED_RED_OPIN, gpio.OUTPUT)
    gpio.mode(TRI_COLOR_RELAY_INDICATOR_LED_GREEN_OPIN, gpio.OUTPUT)
    gpio.mode(TRI_COLOR_RELAY_INDICATOR_LED_BLUE_OPIN, gpio.OUTPUT)
    
    indicate_relay_off_with_no_timer()
    
    gpio.mode(TRI_COLOR_SETUP_LED_RED_OPIN, gpio.OUTPUT)
    gpio.mode(TRI_COLOR_SETUP_LED_GREEN_OPIN, gpio.OUTPUT)
    gpio.mode(TRI_COLOR_SETUP_LED_BLUE_OPIN, gpio.OUTPUT)
    
    indicate_initial_setup_not_done()
end

function indicate_trying_connect_to_external_socket_host_wifi_start_timer()
    gpio.write(TRI_COLOR_SETUP_LED_RED_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_GREEN_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_BLUE_OPIN, gpio.LOW)
    
    tmrBlinkTriColorRed:start()
end

function indicate_trying_to_setup_portable_socket_start_timer()
    gpio.write(TRI_COLOR_SETUP_LED_RED_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_GREEN_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_BLUE_OPIN, gpio.LOW)
    
    tmrBlinkTriColorBlue:start()
end

function indicate_trying_connect_to_external_socket_host_wifi_stop_timer()
    tmrBlinkTriColorRed:stop()
    
    gpio.write(TRI_COLOR_SETUP_LED_RED_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_GREEN_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_BLUE_OPIN, gpio.LOW)
end

function indicate_trying_to_setup_portable_socket_stop_timer()
    tmrBlinkTriColorBlue:stop()
    
    gpio.write(TRI_COLOR_SETUP_LED_RED_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_GREEN_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_BLUE_OPIN, gpio.LOW)
end

function indicate_connected_to_external_socket_host_wifi_but_sntp_sync_not_done()
    gpio.write(TRI_COLOR_SETUP_LED_GREEN_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_BLUE_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_RED_OPIN, gpio.HIGH)
end

function indicate_fixed_socket_mode()
    gpio.write(TRI_COLOR_SETUP_LED_RED_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_BLUE_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_GREEN_OPIN, gpio.HIGH)
end

function inidicate_portable_socket_mode()
    gpio.write(TRI_COLOR_SETUP_LED_RED_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_GREEN_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_SETUP_LED_BLUE_OPIN, gpio.HIGH)
end

function indicate_relay_on_with_timer()
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_RED_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_GREEN_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_BLUE_OPIN, gpio.HIGH)
end

function indicate_relay_off_with_timer()
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_GREEN_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_BLUE_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_RED_OPIN, gpio.HIGH)
end

function indicate_relay_on_with_no_timer()
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_BLUE_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_RED_OPIN, gpio.LOW)
    gpio.write(TRI_COLOR_RELAY_INDICATOR_LED_GREEN_OPIN, gpio.HIGH)
end

function init_gpio_relay_pin()
    gpio.mode(RELAY_OPIN, gpio.OUTPUT)
    
    gpio.write(RELAY_OPIN, gpio.LOW)
end

function reset_gpio_relay_pin(is_for_timer_start_event)
    gpio.write(RELAY_OPIN, gpio.LOW)
    
    if is_for_timer_start_event then
        indicate_relay_off_with_timer()
    else
        indicate_relay_off_with_no_timer()
    end
    
    return gpio.read(RELAY_OPIN) == 0
end

function set_gpio_relay_pin(is_for_timer_start_event)
    gpio.write(RELAY_OPIN, gpio.HIGH)
    
    if is_for_timer_start_event then
        indicate_relay_on_with_timer()
    else
        indicate_relay_on_with_no_timer()
    end
    
    return gpio.read(RELAY_OPIN) == 1
end

function get_gpio_relay_pin_status()
    return gpio.read(RELAY_OPIN)
end

function get_gpio_relay_pin_status_as_boolean()
    return gpio.read(RELAY_OPIN) == 1
end

function urldecode(str)
    str = string.gsub(str, "+", " ")
    str = string.gsub(str, "%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end)
    str = string.gsub(str, "\r\n", "\n")
    return str
end

function set_ap_ip_config ()
--    hardcoding variable value to save flash program space
--    local DEFAULT_AP_SELF_IP = "192.168.10.1"
--    local DEFAULT_AP_NETMASK = "255.255.255.0"
--    local DEFAULT_AP_GATEWAY = "192.168.10.1"
        
    while not wifi.ap.setip({
            ip = "192.168.10.1",
            netmask = "255.255.255.0",
            gateway = "192.168.10.1"
        }) do
    end
end

function set_ap_dhcp_config_and_start_dhcp ()
    local set_ap_dhcp_and_start_dhcp_success_indicator = false
--    local DEFAULT_AP_DHCP_START_IP = "192.168.10.2"       -- hardcoding variable value to save flash program space
    
    while not set_ap_dhcp_and_start_dhcp_success_indicator do
        wifi.ap.dhcp.config ({ start = "192.168.10.2" })
        set_ap_dhcp_and_start_dhcp_success_indicator = wifi.ap.dhcp.start()
    end
end

function is_internet_mode_configured()
    if file.exists(constant_filenames.IS_INTERNET_MODE_CONFIGURED) then
        return '1'
    else
        return '0'
    end
end

--function stop_ap_dhcp_server()
--    while not wifi.ap.dhcp.stop() do end
--end