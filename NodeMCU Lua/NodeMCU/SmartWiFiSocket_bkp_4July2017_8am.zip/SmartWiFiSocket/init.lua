gpio.mode(8, gpio.OUTPUT)
gpio.write(8, gpio.LOW)
--RELAY_OPIN = 8

dofile('SmartWiFiSocket.lua')