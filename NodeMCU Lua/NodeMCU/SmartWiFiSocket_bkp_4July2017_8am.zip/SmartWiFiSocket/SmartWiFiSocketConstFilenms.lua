-- REMOVED CONSTANTS table of tables because of error: "E:M 1592" which indicates having such a huge table in heap memory is causing exhaustion of heap memory and due to that client takes a lot of time to connect to Setup AP

return {
    -- Action/State Indicator Files
    INITIAL_SETUP_DONE = "initial_setup_done",
    IS_INTERNET_MODE_CONFIGURED = "is_internet_mode_configured",
    
    -- On Boot Action/State Indicator Files
    SNTP_SYNC_DONE_ONCE_ON_BOOT = "sntp_sync_done_once_on_boot",
    
    -- Config Persistence
    MDNS_HOSTNAME = "mdns_hostname"
    }