require "SmartWiFiSocket_CommonUtils"

init_wifi_mode(wifi.STATION)
wifi.sta.disconnect()

remove_action_result_indicator_files_on_boot()

local constant_filenames = require "SmartWiFiSocketConstFilenms"

local EXECUTION_MODE_WEB_SERVER_PORT = 9911   -- for both Fixed and Portable mode

local srv=nil

local is_any_timer_running = false
local running_timer_type = nil
local running_timer_end_time = 0
local running_timer_cron_mask_config_string = nil

local cron_scheduled_all_entries = false

local sntp_snyc_retry_cnt = 0

-- Schedule/Timers Entry List
local ONE_SHOT_FUTURE_TIMERS = "OSFT"
local FUTURE_SCHEDULES = "FS"
local RECURRING_SCHEDULES = "RS"
local RECURRING_TIMERS = "RT"

function save_X_entry_to_respective_file(filename, cron_mask_config_string)
    
    local write_success_indicator = false
    local fd = file.open(filename, "a")
    if fd then
        write_success_indicator =  fd:write(cron_mask_config_string .. "\n")
        fd:close()
    end
    fd = nil
    
    return write_success_indicator
end

function remove_saved_X_entry_from_respective_file(filename, cron_mask_config_string)
    
    local fd = file.open(filename, "r")
    local file_contents = fd:read()
    file_contents = file_contents:gsub(cron_mask_config_string .. "\n", "")
    fd:close()
    
    local write_success_indicator = false
    fd = file.open(filename, "w+")
    if fd then
        write_success_indicator =  fd:write(file_contents)
        fd:close()
    end
    fd = nil
    
    return write_success_indicator
end

--function cron_OSFT_schedule(cron_mask_config_string)
--    local _, _, cron_mask, in_year, before_state, timer_duration_secs, after_state = string.find(cron_mask_config_string, '([^=]+)=([^=]+)=(.)=([^=]+)=(.)')
--    cron_mask = cron_mask:gsub('_', ' ')
    
--    do
--        cron_mask_config_string_in_use = cron_mask_config_string
--        in_year_in_use = in_year
--        before_state_in_use = before_state
--        timer_duration_secs_in_use = timer_duration_secs
--        after_state_in_use = after_state
        
--        function schedule_callback(e)
--            local current_year = rtctime.epoch2cal(rtctime.get())['year']
--            if tonumber(current_year) == tonumber(in_year_in_use) then
--                local before_state_setting = false
--                if before_state_in_use == '1' then
--                    before_state_setting = set_gpio_relay_pin(true)
--                else
--                    before_state_setting = reset_gpio_relay_pin(true)
--                end
                
--                if before_state_setting then
--                    is_any_timer_running = true
--                    running_timer_type = "osft"
--                    running_timer_cron_mask_config_string = cron_mask_config_string_in_use
--                    current_rtctime = rtctime.get()
                    
--                    if current_rtctime ~= nil then
--                        running_timer_end_time = current_rtctime+tonumber(timer_duration_secs_in_use)
                                            
--                        tmr.create():alarm(tonumber(timer_duration_secs_in_use)*1000, tmr.ALARM_SINGLE, function(t)
--                            local after_state_setting = false
--                            if after_state_in_use == '1' then
--                                after_state_setting = set_gpio_relay_pin(false)
--                            else
--                                after_state_setting = reset_gpio_relay_pin(false)
--                            end
                            
--                            if after_state_setting then
--                                is_any_timer_running = false
--                                remove_saved_X_entry_from_respective_file(cron_mask_config_string_in_use, ONE_SHOT_FUTURE_TIMERS)
--                            end
--                        end)
--                    end
--                end
--            end
--        end
--    end
    
--    cron.schedule(cron_mask, schedule_callback)
--    return true
--end

function cron_FS_schedule(cron_mask_config_string)
    local _, _, cron_mask, in_year, desired_state = string.find(cron_mask_config_string, '([^=]+)=([^=]+)=(.)')
    cron_mask = cron_mask:gsub('_', ' ')
    
    do
        cron_mask_config_string_in_use = cron_mask_config_string
        in_year_in_use = in_year
        desired_state_in_use = desired_state
        
        function schedule_callback(e)
            local current_year = rtctime.epoch2cal(rtctime.get())['year']
            if tonumber(current_year) == tonumber(in_year_in_use) then
                if desired_state_in_use == '1' then
                    set_gpio_relay_pin(false)
                else
                    reset_gpio_relay_pin(false)
                end
                
                remove_saved_X_entry_from_respective_file(cron_mask_config_string_in_use, FUTURE_SCHEDULES)
            end
        end
    end
    
    cron.schedule(cron_mask, schedule_callback)
    return true
end

function save_FS_entry_and_cron_schedule(cron_mask_config_string)
    if save_X_entry_to_respective_file(FUTURE_SCHEDULES, cron_mask_config_string) then
        return cron_FS_schedule(cron_mask_config_string)
    else
        return false
    end
end

function start_fixed_mode_web_server()
--    To test: http://<resolved IP address from mdns hostname>:9911
--    Endpoint 1  to set gpio relay pin: /gpio/relay/1      (should work irrespective of sntp done or not)
--    Endpoint 2  to reset gpio relay pin: /gpio/relay/0    (should work irrespective of sntp done or not)
--    Endpoint 3  to get gpio relay pin status: /gpio/relay_status (should work irrespective of sntp done or not)
    
    srv=nil
    collectgarbage()
    
    srv=net.createServer(net.TCP)   --make http server
    
    if srv then
        srv:listen(EXECUTION_MODE_WEB_SERVER_PORT, function(conn)
                conn:on("receive", function(client_conn, payload)
                        --print(payload)
                
                        local _, _, method, path, vars = string.find(payload, "([A-Z]+) (.+)?(.+) HTTP")
                        if (method == nil)
                        then
                            _, _, method, path = string.find(payload, "([A-Z]+) (.+) HTTP")
                        end

                        client_conn:send("HTTP/1.1 200 OK\n")
                        client_conn:send("Content-Type: text/plain\n\n")
                        if method == 'GET' then
                            if path == '/gpio/relay_status' then
                                if is_any_timer_running then
                                    if get_gpio_relay_pin_status_as_boolean() then
                                        client_conn:send("2" .. is_internet_mode_configured() .. "~" .. running_timer_type .. ";" .. running_timer_cron_mask_config_string .. ";" .. (running_timer_end_time-rtctime.get()))
                                    else
                                        client_conn:send("3" .. is_internet_mode_configured() .. "~" .. running_timer_type .. ";" .. running_timer_cron_mask_config_string .. ";" .. (running_timer_end_time-rtctime.get()))
                                    end
                                else
                                    if get_gpio_relay_pin_status_as_boolean() then
                                        client_conn:send("1" .. is_internet_mode_configured())
                                    else
                                        client_conn:send("0" .. is_internet_mode_configured())
                                    end
                                end
                            elseif path == '/gpio/relay/1' then
                                if set_gpio_relay_pin(false) then
                                    client_conn:send("success")
                                else
                                    client_conn:send("error")
                                end
                            elseif path == '/gpio/relay/0' then
                                if reset_gpio_relay_pin(false) then
                                    client_conn:send("success")
                                else
                                    client_conn:send("error")
                                end
                            elseif path == '/set_new_osct' then
                                if file.exists(constant_filenames.SNTP_SYNC_DONE_ONCE_ON_BOOT) and sntp_snyc_retry_cnt <= 16 then
                                    if is_any_timer_running then
                                        client_conn:send("error_another_timer_running")
                                    else
                                        local _, _, cron_mask_config_string = string.find(vars, 'cron_mask_config_string=([^&]+)')
                                        cron_mask_config_string = urldecode(cron_mask_config_string)
                                        local _, _, before_state, timer_duration_secs, after_state = string.find(cron_mask_config_string, '(.)=([^=]+)=(.)')
                                        
                                        local before_state_setting = false
                                        if before_state == '1' then
                                            before_state_setting = set_gpio_relay_pin(true)
                                        else
                                            before_state_setting = reset_gpio_relay_pin(true)
                                        end
                                        
                                        if before_state_setting then
                                            is_any_timer_running = true
                                            running_timer_type = "osct"
                                            running_timer_cron_mask_config_string = cron_mask_config_string
                                            current_rtctime = rtctime.get()
                                            
                                            if current_rtctime == nil then
                                                client_conn:send("error_no_rtc")
                                            else
                                                running_timer_end_time = current_rtctime+tonumber(timer_duration_secs)
                                            
                                                tmr.create():alarm(tonumber(timer_duration_secs)*1000, tmr.ALARM_SINGLE, function(t)
                                                    local after_state_setting = false
                                                    if after_state == '1' then
                                                        after_state_setting = set_gpio_relay_pin(false)
                                                    else
                                                        after_state_setting = reset_gpio_relay_pin(false)
                                                    end
                                                    
                                                    if after_state_setting then
                                                        is_any_timer_running = false
                                                    end
                                                end)
                                            
                                                client_conn:send("success")
                                            end
                                        else
                                            client_conn:send("error")
                                        end
                                    end
                                else
                                    client_conn:send("error_no_rtc")
                                end
                            elseif path == '/save_new_schedule_timer_entry' then   -- for OSFT, FS, RS, RT
                                if file.exists(constant_filenames.SNTP_SYNC_DONE_ONCE_ON_BOOT) and sntp_snyc_retry_cnt <= 16 then
                                    if is_any_timer_running then
                                        client_conn:send("error_another_timer_running")
                                    else
                                        local _, _, schedule_timer_type = string.find(vars, 'schedule_timer_type=([^&]+)')
                                        local _, _, cron_mask_config_string = string.find(vars, 'cron_mask_config_string=([^&]+)')
                                        cron_mask_config_string = urldecode(cron_mask_config_string)
                                        
                                        local save_X_entry_and_cron_schedule = nil
                                        if schedule_timer_type == "OSFT" then
                                            save_X_entry_and_cron_schedule = nil
                                        elseif schedule_timer_type == "FS" then
                                            save_X_entry_and_cron_schedule = save_FS_entry_and_cron_schedule
                                        elseif schedule_timer_type == "RS" then
                                            save_X_entry_and_cron_schedule = nil
                                        elseif schedule_timer_type == "RT" then
                                            save_X_entry_and_cron_schedule = nil
                                        end
                                        
                                        if save_X_entry_and_cron_schedule ~= nil and save_X_entry_and_cron_schedule(cron_mask_config_string) then
                                            client_conn:send("success")
                                        else
                                            client_conn:send("error")
                                        end
                                    end
                                else
                                    client_conn:send("error_no_rtc")
                                end
                            else
                                client_conn:send("error")
                            end
                        end
                    end)
                conn:on("sent", function(client_conn)
                        client_conn:close()
                        collectgarbage()
                    end)
            end)
    end
end

function stop_fixed_mode_web_server()
    if srv ~= nil then
        srv:close()
        srv=nil
        collectgarbage()
    end
end

wifi.eventmon.register(wifi.eventmon.STA_GOT_IP, function(tbl)
        
        indicate_trying_connect_to_external_socket_host_wifi_stop_timer()
        indicate_connected_to_external_socket_host_wifi_but_sntp_sync_not_done()
        
        fd = file.open(constant_filenames.MDNS_HOSTNAME, 'r')
        mdns.register(fd:read(), { service="http", port = EXECUTION_MODE_WEB_SERVER_PORT })
        fd:close()
        fd = nil
        
        start_fixed_mode_web_server()
        
        if file.exists(constant_filenames.SNTP_SYNC_DONE_ONCE_ON_BOOT) then
            if sntp_snyc_retry_cnt <= 16 then
                indicate_fixed_socket_mode()
            else
                indicate_connected_to_external_socket_host_wifi_but_sntp_sync_not_done()
                cron.reset()
                cron_scheduled_all_entries = false
            end
        else
            sntp_sync_time()
        end
    end)

wifi.eventmon.register(wifi.eventmon.STA_DISCONNECTED, function(tbl)
        stop_fixed_mode_web_server()
        mdns.close()
        
        indicate_trying_connect_to_external_socket_host_wifi_start_timer()
        wifi.sta.connect()
    end)

function sntp_sync_time()
--    sntp.sync({ "1.in.pool.ntp.org", "0.asia.pool.ntp.org", "2.asia.pool.ntp.org", "ntp1.iitd.ac.in", "ntp2.iitd.ac.in" }, function(sec, usec, server, info)
--            rtctime.set(sec + 19800)
--        end,
--        sntp_sync_time, 1)
    -- 19800 secs = 5.5 hours IST
    sntp.sync(nil, function(sec)
            rtctime.set(sec + 19800)
            
            sntp_snyc_retry_cnt = 0
            
            if not file.exists(constant_filenames.SNTP_SYNC_DONE_ONCE_ON_BOOT) then
                create_action_result_indicator_file(constant_filenames.SNTP_SYNC_DONE_ONCE_ON_BOOT)
            end
            
            indicate_fixed_socket_mode()
        end, function()
                sntp_snyc_retry_cnt = sntp_snyc_retry_cnt + 1
            
                -- SNTP SYNC was done once on boot and after that if couldn't sntp sync till 16 times (4 hours tried syncing every 15 mins) then show red led on
                if file.exists(constant_filenames.SNTP_SYNC_DONE_ONCE_ON_BOOT) and sntp_snyc_retry_cnt <= 16 then
                    indicate_fixed_socket_mode()
                else
                    indicate_connected_to_external_socket_host_wifi_but_sntp_sync_not_done()
                    cron.reset()
                    cron_scheduled_all_entries = false
                end
            end, 1)
end

indicate_trying_connect_to_external_socket_host_wifi_start_timer()
wifi.sta.connect()

if not file.exists(ONE_SHOT_FUTURE_TIMERS) then
    create_action_result_indicator_file(ONE_SHOT_FUTURE_TIMERS)
end

if not file.exists(FUTURE_SCHEDULES) then
    create_action_result_indicator_file(FUTURE_SCHEDULES)
end

if not file.exists(RECURRING_SCHEDULES) then
    create_action_result_indicator_file(RECURRING_SCHEDULES)
end

if not file.exists(RECURRING_TIMERS) then
    create_action_result_indicator_file(RECURRING_TIMERS)
end

cron.reset()
cron_scheduled_all_entries = false

function post_state_to_internet ()
    
end

function get_action_from_internet ()
    
end